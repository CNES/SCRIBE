/*
 * Created on 21 oct. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package generic;



import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import scribe.ded.DEDAttribute;

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class phrDoc {
	// Liste non exhaustive : � compl�ter selon le besoin
	private static String[] HTMLTags = {"li", "/li", "ul", "/ul", "br","b", "/b", "table", "/table", "tr", "/tr", "th", "/th", "td", "/td", "font", "/font", "u", "/u"};
	private static Set attributsImprimes = null;
	private static String printCurrentAttributes(Map attributs, boolean phrManagement) {
		String def = "";
		if (attributs != null)  {
			Set s = attributs.entrySet();
			Iterator i = s.iterator();
			while (i.hasNext()) {
				Map.Entry e =  (Map.Entry)i.next();
				String key = (String)e.getKey();
				if ((!key.equals("EAST_PATH")) && (!key.equals("DEFINITION"))) {
				// if (!key.equals("EAST_PATH")) {
					if ((phrManagement) || (!key.equals("ISSUE"))) 
					if (!attributsImprimes.contains(key)) {
						if (key.equals("ILLUSTRATION")) {
							Collection c = (Collection)e.getValue();
							if (c != null) {
								Iterator it = c.iterator();
								while (it.hasNext()) {
									DEDAttribute att = (DEDAttribute) it.next();
									String value = att.getValue();
									def += "<a href=\"" + value +"\">Illustration</a><br>";
								}
							}
							
						}
						else {
							// Soit l'attribut est � occurrence unique
							// et la valeur est une String
							// Soit l'attribut est multiple
							// et la valeur est une Collection
							// Soit l'attribut est complexe et ...
							
							try {
								
								Collection c = (Collection)e.getValue();
								if (c != null) {
									Iterator it = c.iterator();
									while (it.hasNext()) {
									
										DEDAttribute att = (DEDAttribute) it.next();
										String value = "";
										if (att.getType().equals("SIMPLE_ATTRIBUTE")) {
											value = att.getValue();
											String cle = key.substring(0,1) + key.substring(1).toLowerCase();
											def += "<b>"+cle+"</b> : " + value + "<br>";
										}
										else {
											String cle = key.substring(0,1) + key.substring(1).toLowerCase();
											def += "<b>"+cle+"</b> : ";
											Map m = att.getAttrChildren();
											String sousDef = printCurrentAttributes(m, false);
											
											def += sousDef.replaceFirst("<br>", "   " );
										}
											
									}
								}
							} catch (RuntimeException e1) {
								String value = (String)e.getValue();
								String cle = key.substring(0,1) + key.substring(1).toLowerCase();
								def += "<b>"+cle+"</b> : " + value + "<br>";
							}					
						}
						
						attributsImprimes.add(key);
					}
				}
				
			}
		}
		return def;
	}
	
	
	public static String print(Map attributsElement, Map attributsType, boolean phrManagement) {
		String complement = "";
		String typeDef = "";
		String fieldDef = "";
		
		attributsImprimes = new TreeSet();
		fieldDef = printCurrentAttributes(attributsElement, phrManagement);
		typeDef = printCurrentAttributes(attributsType, phrManagement);
		
		if (!typeDef.equals("")) {
			complement = typeDef ;
		}
		if (!fieldDef.equals("")) {
			complement += fieldDef;
		}
		// complement = complement.replaceAll("\n","<br>");
		int debut = complement.indexOf("<table");
		int fin = 0;
		String res = "";
		
		while (debut != -1) {
			res += complement.substring(fin,debut).replaceAll("\n","<br>");
			fin = complement.indexOf("</table>", debut);
			fin += 8;
			res += complement.substring(debut,fin);
			debut = complement.indexOf("<table", fin);  
		}
		res += complement.substring(fin).replaceAll("\n","<br>");
		return res;
	}
	
	public static String restoreHTMLTag(String in) {
		
		String res = in;
		// Il faut remplacer les "&lt;" en "<"
		// mais uniquement pour les balises HTML
		
		// Modif de Scribe � partir de 3.1.41
		// Le comportement est invers� :
		// on remet les &lt; � la place des < 
		
		res = res.replaceAll("<", "&lt;");

		for (int i=0; i < HTMLTags.length; i++) {
			res = res.replaceAll("&lt;"+HTMLTags[i],"<"+HTMLTags[i]);
		}
		
		

		return res;
		
	}
	
	public static String indent(String in) {
		String res = in;
		// On remplace les "<br>" par des "</p><p>"
		// puis on cherche les tabulations
		res = res.replaceAll("<br>","</p><p>");
		
		int pos = res.indexOf("<p>");
		int debut = pos;
		while (pos != -1) {
			// on compte le nombre de tabulations
			int n = 0;
			pos = pos + 3;
			try {
			while ((res.charAt(pos) == '\t') ||(res.charAt(pos) == ' ')) {
				if (res.charAt(pos) == '\t') n = n+ 3;
				pos++;
			}
			}
			catch (Exception e) {
				// rien : juste pour traiter le cas ou pas d�passe la taille de res
			}
			if (n > 0) {
				int padding = 10*n;
				res = res.substring(0,debut) +
				   "<p  style=\"text-indent: " + new Integer(padding) + "pt;\">" +
				   res.substring(pos, res.length());
			}
			
			pos = res.indexOf("<p>", pos);
			debut = pos;
		}
		
		
		return res;
		
	}

}
