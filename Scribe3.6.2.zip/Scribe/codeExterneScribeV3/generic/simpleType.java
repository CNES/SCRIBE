/*
 * Created on 3 nov. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package generic;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import scribe.ded.DEDAnyType;
import scribe.ded.DEDDataEntity;
import scribe.ded.DEDEnumeratedType;
import scribe.ded.DEDEnumeration;
import scribe.ded.DEDIntegerType;
import scribe.ded.DEDListType;
import scribe.ded.DEDRealType;
import scribe.ded.DEDTextType;
import scribe.ded.DEDUnionType;
import scribe.ded.DEDXMLAttribute;

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class simpleType {
	
	private static HashMap<String, String> lesAttributs = new HashMap<String, String>();
	
	public static String printAttribut(DEDXMLAttribute att) {
		String res = print(att.getDataType());
		// On compl�te par un �ventuel pattern
		if (att.getDataType() instanceof DEDTextType) {
			String pat = ((DEDTextType)(att.getDataType())).getPattern();
			if (pat.length() > 0) {
				res += " with Pattern : " + pat;
			}
		}
		return res;
	}
	
	public static String print(DEDAnyType any) {
		DEDAnyType base = any;
		String name = "";
		while (base != null) {
			name = base.getName();
			base = (DEDAnyType)base.getBaseType();
		}
		return name;
	}
	
	public static String print(DEDListType l) {
		String description = "";
		String itemType = l.getItemTypeString();
		   if (itemType.equals("REAL_TYPE")) {
		   	description += print((DEDRealType)l.getItemType());
		   }
		   else if (itemType.equals("INTEGER_TYPE")) {
		   	description += print((DEDIntegerType)l.getItemType());
		   }
		   else if (itemType.equals("ENUMERATED_TYPE")) {
		   	description += print((DEDEnumeratedType)l.getItemType());
		   }
		   else if (itemType.equals("TEXT_TYPE")) {
		   	description += print((DEDTextType)l.getItemType());
		   }
		   else if (itemType.equals("ANY_TYPE")) {
		   	description += print((DEDAnyType)l.getItemType());
		   }
		   else  {
		     // Cas pas pr�vu
		     description = "<font color=\"red\">" + l.getItemTypeString() + " </font>";
		   }

		   description += " * " ;
		   String max = l.getLength();
		   String min = max;
		   if (max == null) {
		      // non fixe 
		      min = l.getMinLength();
		      max = l.getMaxLength();
		   }
		   if (max == null) max = "n";
		   if (min == null) min = "0";
		   if (min.equals(max)) description += max;
		   else description += "(" + min + " .. " + max + ")";
		return description;
	}
		
	public static String print(DEDUnionType u) {
		String description = "";
		Collection<?> c = u.getMembersList();
		Iterator<?> it = c.iterator();
		while (it.hasNext()) {
			Object o = it.next();
			String memberType = DEDDataEntity.getTypeStringFromType(o);
			if (memberType.equals("REAL_TYPE")) {
				description += print((DEDRealType)o);
			}
			else if (memberType.equals("INTEGER_TYPE")) {
				description += print((DEDIntegerType)o);
			}
			else if (memberType.equals("ENUMERATED_TYPE")) {
				description += print((DEDEnumeratedType)o);
			}
			else if (memberType.equals("TEXT_TYPE")) {
				description += print((DEDTextType)o);
				
			}
			else if (memberType.equals("ANY_TYPE")) {
			   	description += print((DEDAnyType)o);
			   }
			else  {
				// Cas pas pr�vu
				description = "<font color=\"red\">" + memberType + " </font>";
			}
			description += " | " ;
		}
		if (description.endsWith(" | ")) {
			description = description.substring(0,description.length() - 3);
		}
		return description;
	}
		
	public static String print(DEDTextType t) {
		String description = "";
		String max = t.getMaxSize();
		   String min = t.getMinSize(); 
		   // Attention : si le document source est en DEDSL
		   // ou si le document est en XML Schema
		   // les valeurs non reseign�es ne sont par identiques
		   // -1 ou null
		   
		   if (min == null) min = "0";
		   if (max == null) max = "-1";
		   if (max.equals("1") || max.equals("")) {
		      description += "Character";
		   }
		   else if (max.equals("-1")) {
		      // taille indefinie
		      description += "String";
		   } 
		   else if (max.equals(min)) {
		      description += max + " " + "Characters";
		   }
		   else {
		      description += min + " .. " + max + " " + "Characters";
		   }
		   // On adapte la sortie
		   if (description.startsWith("0 Character")) {
			   description = "Empty String";
		   }
		  
		return description;
	}
	public static String print(DEDRealType r) {
		String description = "Float";
		String min = r.getMinValue();
		String max = r.getMaxValue();
		if ((min != null) || (max != null)) {
			if (min == null) min = "";
			if (max == null) max = "";
			if ((!min.equals("")) || (!max.equals(""))) {
				if (r.isMinExcluded()) description += " ]";
				else description += " [";
				description += min + " .. "+max;
				if (r.isMaxExcluded()) description += "[";
				else description += "]";
			}
		}	
		return description;
	}
	public static String print(DEDIntegerType i) {
		String description = "Integer";
		String min = i.getMinValue();
		String max = i.getMaxValue();
		if ((min != null) || (max != null)) {
			if (min == null) min = "";
			if (max == null) max = "";
			if ((!min.equals("")) || (!max.equals(""))) {
				if (i.isMinExcluded()) description += " ]";
				else description += " [";
				if (min.equals(max)) description += min;
				else description += min + " .. "+max;
				if (i.isMaxExcluded()) description += "[";
				else description += "]";
			}
		}
		return description;
	}
	public static String print(DEDEnumeratedType e) {
		String description = "";
		String enumeration = "Enumeration";
		List<DEDEnumeration> al = e.getEnumerations();
		List<DEDEnumeration> subList = new ArrayList<DEDEnumeration>();
		DEDEnumeration valEnum;
		int size = al.size();
		 
		String rawType = e.getRawType().getClass().getName();
		if (rawType.contains("Integer")) {
			// Traitement sp�cifique pour prendre en compte des facettes propres � ce type
			String minIncl = e.getMinInclusive();
			if (minIncl != null) {
				long min = new Long(minIncl).longValue();
				long val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Long(((DEDEnumeration)al.get(i)).getValue()).longValue();
				      if (val >= min) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
			String minExcl = e.getMinExclusive();
			if (minExcl != null) {
				long min = new Long(minExcl).longValue();
				long val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Long(((DEDEnumeration)al.get(i)).getValue()).longValue();
				      if (val > min) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
			String maxIncl = e.getMaxInclusive();
			if (maxIncl != null) {
				long max = new Long(maxIncl).longValue();
				long val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Long(((DEDEnumeration)al.get(i)).getValue()).longValue();
				      if (val <= max) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
			String maxExcl = e.getMaxExclusive();
			if (maxExcl != null) {
				long max = new Long(maxExcl).longValue();
				long val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Long(((DEDEnumeration)al.get(i)).getValue()).longValue();
				      if (val < max) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
		}
		
		if (rawType.contains("Real")) {
			// Traitement sp�cifique pour prendre en compte des facettes propres � ce type
			String minIncl = e.getMinInclusive();
			if (minIncl != null) {
				double min = new Double(minIncl).doubleValue();
				double val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Double(((DEDEnumeration)al.get(i)).getValue()).doubleValue();
				      if (val >= min) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
			String minExcl = e.getMinExclusive();
			if (minExcl != null) {
				double min = new Double(minExcl).doubleValue();
				double val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Double(((DEDEnumeration)al.get(i)).getValue()).doubleValue();
				      if (val > min) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
			String maxIncl = e.getMaxInclusive();
			if (maxIncl != null) {
				double max = new Double(maxIncl).doubleValue();
				double val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Double(((DEDEnumeration)al.get(i)).getValue()).doubleValue();
				      if (val <= max) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
			String maxExcl = e.getMaxExclusive();
			if (maxExcl != null) {
				double max = new Double(maxExcl).doubleValue();
				double val;
				for (int i=0; i < size; i++) {
				      valEnum = (DEDEnumeration)al.get(i);
				      val = new Double(((DEDEnumeration)al.get(i)).getValue()).doubleValue();
				      if (val < max) {
				    	  subList.add(valEnum);
				      }
				}
				al = subList;
				size = al.size();
				subList = new ArrayList<DEDEnumeration>();
			}
		}
			
		
		   if (size > 1)
		      description += enumeration + " [";
		   for (int i=0; i < size; i++) {
		      valEnum = (DEDEnumeration)al.get(i);
		      description += " \""  + valEnum.getValue() + "\" ";
		   }

		   if (size > 1) description += "]";
		   return description;
	}
	public static String print(Object obj) {
		String classType = obj.getClass().getName();
		if (classType.indexOf("EnumeratedType") != -1) 
			return print( (DEDEnumeratedType)obj);
		else if (classType.indexOf("IntegerType") != -1) 
			return print( (DEDIntegerType)obj);
		else if (classType.indexOf("RealType") != -1) 
			return print( (DEDRealType)obj);
		else if (classType.indexOf("TextType") != -1) 
			return print( (DEDTextType)obj);
		else if (classType.indexOf("UnionType") != -1) 
			return print( (DEDUnionType)obj);
		else if (classType.indexOf("ListType") != -1) 
			return print( (DEDListType)obj);
		else if (classType.indexOf("AnyType") != -1) 
			return print( (DEDAnyType)obj);
		else 	// Complexe : Hors scope
			return "";
	}
	
	// Copie de X_Type_Interne +
	// simplification car r�cursivit� possible
	public static String print(DEDDataEntity dataDef) {
		String description = "";
		

		if (dataDef.isEnumerated()) {
			description = print( (DEDEnumeratedType)dataDef.getEntityType());
			if (description.indexOf("TO_BE_DEFINED") != -1) {
				   description = "<font color=\"red\">TBD</font>";
				}
			}
			if (dataDef.isInteger()) {
				description = print( (DEDIntegerType)dataDef.getEntityType());
			   
			}
			if (dataDef.isReal()) {
				description = print( (DEDRealType)dataDef.getEntityType());
			   
			}
			if (dataDef.isText()) {
				description = print( (DEDTextType)dataDef.getEntityType());
			   
			}
			if (dataDef.isUnion()) {
				description = print( (DEDUnionType)dataDef.getEntityType());
			   
			}
			if (dataDef.isList()) {
				description = print( (DEDListType)dataDef.getEntityType());
			   
			}
			if (dataDef.isAny()) {
				description = print((DEDAnyType)dataDef.getEntityType());
			}
			if (dataDef.isComposite()) {
				// Hors scope
				return "";
			}

			if (description.equals("")) {
			   description = "<font color=\"red\">undefined</font>";
			}

		return description;
	}
	
	public static String shortDefinition(DEDDataEntity dataDef) {
		String def = dataDef.getShortDefinition();
		

		if (def != null) {
		   def += "<br>";
		}
		else def = "";
		def = def.replaceAll("\n","<br>");
		if (def.equals("<br>")) def = "";
		return def;
	}
	public static String printPattern(DEDDataEntity dataDef) {
		String res = "";
		if  (dataDef.getDEDClass().equals("DATA_FIELD")) {
			if (dataDef.getInheritsFrom() != null) {
				dataDef = dataDef.getInheritsFrom();
			}
		}
		String classType = dataDef.getEntityType().getClass().getName();
		if (classType.indexOf("EnumeratedType") != -1) 
			// res =  ((DEDEnumeratedType)dataDef.getEntityType()).getPattern();
			res = "";
		else if (classType.indexOf("IntegerType") != -1) 
			res =  ( (DEDIntegerType)dataDef.getEntityType()).getPattern();
		else if (classType.indexOf("RealType") != -1) 
			res =  ( (DEDRealType)dataDef.getEntityType()).getPattern();
		else if (classType.indexOf("TextType") != -1) 
			res =  ( (DEDTextType)dataDef.getEntityType()).getPattern();
		else if (classType.indexOf("UnionType") != -1) 
			// res =  ( (DEDUnionType)dataDef.getEntityType()).getPattern();
			res = "";
		else if (classType.indexOf("ListType") != -1) 
			//res =  ( (DEDListType)dataDef.getEntityType()).getPattern();
			res = "";
		else if (classType.indexOf("AnyType") != -1) 
			res =  ( (DEDAnyType)dataDef.getEntityType()).getPattern();
		
		if (res != null) {
			
//			 Patch sur version 3.1.38
			   if ((!res.equals("")) && (!res.equals("[\\-+]?[0-9]+"))) {
				res = "<b> Pattern : </b>" + res + "<br>"; 
			   }
			   else res = ""; 
			   
		}
		else res = "";
		return res;
	}
	private static Collection<?> getDEDXMLAttributes(DEDDataEntity dataDef) {
		Collection<?> col =  null;
		// col = dataDef.getEntityType().getDEDXMLAttributes();
		String classType = dataDef.getEntityType().getClass().getName();
		if (classType.indexOf("EnumeratedType") != -1) 
			col =  ((DEDEnumeratedType)dataDef.getEntityType()).getDEDXMLAttributes();
		else if (classType.indexOf("IntegerType") != -1) 
			col =  ( (DEDIntegerType)dataDef.getEntityType()).getDEDXMLAttributes();
		else if (classType.indexOf("RealType") != -1) 
			col =  ( (DEDRealType)dataDef.getEntityType()).getDEDXMLAttributes();
		else if (classType.indexOf("TextType") != -1) 
			col =  ( (DEDTextType)dataDef.getEntityType()).getDEDXMLAttributes();
		else if (classType.indexOf("UnionType") != -1) 
			col =  ( (DEDUnionType)dataDef.getEntityType()).getDEDXMLAttributes();
		else if (classType.indexOf("ListType") != -1) 
			col =  ( (DEDListType)dataDef.getEntityType()).getDEDXMLAttributes();
		else if (classType.indexOf("AnyType") != -1) 
			col =  ( (DEDAnyType)dataDef.getEntityType()).getDEDXMLAttributes();
		return col;
	}
	
	public static String printStoredAttributs() {
		String res = "";
		
		if ( lesAttributs != null) {
			Set<?> s = lesAttributs.entrySet();
			Iterator<?> i = s.iterator();
			while (i.hasNext()) {
			   Map.Entry e =  (Map.Entry)i.next();
			   String key = (String)e.getKey();
			   String value = (String)e.getValue();
			   res += key + value;
			}
		}
		lesAttributs.clear();
		return res;
	}
	// Copie de X_attribut
	public static String storeAttribut(DEDDataEntity dataField) {
		String path = null;
		DEDDataEntity dataDef = null;
		String name = null;
		String res = "";
		if ( dataField.getInheritsFrom() != null ) {
			dataDef = dataField.getInheritsFrom();
			//				 Verrue pour Scribe V3.1.3
			
			if (dataDef.getName().indexOf("http://www.w3.org/2001/XMLSchema:") != -1) {
				dataDef = dataField;
				path = dataField.getEastPath()+".";
			}
			else {
				path = dataDef.getName()+".";
			}
		}
		else {
			dataDef = dataField;
			path = dataField.getEastPath()+".";
		}
		Collection<?> col =  getDEDXMLAttributes(dataDef);
		
		if (col != null) {
		   Iterator<?> it = col.iterator(); 
		   while (it.hasNext()) {
		      DEDXMLAttribute att = (DEDXMLAttribute)it.next();
		      name = att.getName();
		      res += "<b> Attribut : </b> <a href=\"#" + shortName.get(path + name) +"\">"+name+"</a><br>"; 
		      String ancre = "<a name=\"" + shortName.get(path + name) + "\">";
		      if (!lesAttributs.containsKey(ancre)) {
		         String type = print(att.getDataType());
		         String option = "Optionnel";
		         if (att.isRequired()) option = "Requis";
		         lesAttributs.put(ancre,"<b>"+name+ "</b> " +type+" - "+option + "<br>");
		     }
		   }
		}

		return res ;
	}
	
	public static String printAttributs(DEDDataEntity model) {
		String res = "";
		String name = "";
		
//		 Verrue pour Scribe V3.1.3
		
		if (model.getName().indexOf("http://www.w3.org/2001/XMLSchema:") != -1) {
			return "";
		}
		Collection<?> col =  getDEDXMLAttributes(model);
		
		if (col != null) {
			Iterator<?> it = col.iterator(); 
			while (it.hasNext()) {
				DEDXMLAttribute att = (DEDXMLAttribute)it.next();
				name = att.getName();
				String type = print(att.getDataType());
				String option = "Optionnel";
				if (att.isRequired()) option = "Requis";
				res += "<b> Attribut : </b>" + "<b>"+name+ "</b> " +type+" - "+option + "<br>";
			}
		}
		return res;
		
	}

	public static String definition(DEDDataEntity dataDef) {
		String def = null;

		def = dataDef.getDefinition();

		if (def != null) {
		   def += "<br>";
		}
		else def = "";
		
//		 Comportement bizarre de Xerces qui 
		// transforme les '<' en &lt;
		// def = def.replaceAll("&lt;", "<");
		def = phrDoc.restoreHTMLTag(def);

//		def = def.replaceAll("\n","<br>");
		int debut = def.indexOf("<table");
		int fin = 0;
		String res = "";

		while (debut != -1) {
		   res += def.substring(fin,debut).replaceAll("\n","<br>");
		   fin = def.indexOf("</table>", debut);
		   fin += 8;
		   res += def.substring(debut,fin);
		   debut = def.indexOf("<table", fin);  
		}
		res += def.substring(fin).replaceAll("\n","<br>");
		if (res.equals("<br>")) res = "";
		return res;
	}

}
