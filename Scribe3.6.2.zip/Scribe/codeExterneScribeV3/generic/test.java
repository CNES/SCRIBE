package generic;
import java.util.Collection;
import java.util.Locale;

import org.apache.log4j.xml.DOMConfigurator;

import XSImport.parser.Messages;
import scribe.ded.DEDDataEntity;
import scribe.ded.DEDDictionary;
import scribe.ded.DEDParseException;
import scribe.ded.DEDTextType;
import scribe.ded.DEDXMLAttribute;
import scribe.ded.Localisation;
import scribe.ded.generator.DEDFactory;


/*
 * Created on 24 nov. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class test {

	public static void main(String[] args) {
		Messages.setCurrentLocale(new Locale("fr", ""));
		Localisation.setCurrentLocale(new Locale("fr", ""));
		DOMConfigurator.configure("log4j.xml");
		DEDFactory loader = new DEDFactory();
		String XSD = "N:\\Support\\Taranis\\XSD2FORM\\Modeles XSD\\Spec pour ADS\\TMs_CU.xsd";
		
						
						try {
							loader.loadFileName(XSD);
							
							DEDDictionary dictionary = loader.getDictionary();
							/*
							TreeMap types = new TreeMap(dictionary.getModelMap());
							dico.setSource(XSD);
							String res = dico.printTypes(types);
							System.out.println(res);
							PrintWriter P = new PrintWriter("resTest.html");
							P.print(res);
							P.close();
							*/
							
							DEDDataEntity field = dictionary.getDataEntityFromEastPath("root.TMs_ChargeUtile.TM_ChargeUtile.Classe");
							Collection col = ((DEDTextType)(field.getEntityType())).getDEDXMLAttributes();
							DEDXMLAttribute att = (DEDXMLAttribute)col.iterator().next();
						    String  name = att.getName();
						    String type = simpleType.print(att.getDataType());
						    
						    System.out.println(name + " " + type);
						    
						    System.out.println(simpleType.printAttributs(field));
						    System.out.println(simpleType.printAttribut(att));
						    
						    
						} catch (DEDParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}	
						
					

			
		
	}
}
