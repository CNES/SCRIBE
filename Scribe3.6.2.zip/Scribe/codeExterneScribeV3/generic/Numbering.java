package generic;

import java.util.Set;
import java.util.TreeMap;

import scribe.ded.DEDDataEntity;

public class Numbering {

	/**
	 * @param args
	 */
	private static Integer currentLevel = new Integer(0);

	private static TreeMap<Integer, Integer> numerotation = new TreeMap<Integer, Integer>(
			new IntegerValueComparator());
	private static void addLevel() {
		currentLevel = currentLevel + 1;
		// init the value
		numerotation.put(currentLevel, 1);
	}
	private static void decrementLevel() {
		numerotation.remove(currentLevel);
		currentLevel = currentLevel - 1;
		incrementNum();
	}
	private static void incrementNum() {
		Integer currentValue = numerotation.get(currentLevel);
		if (currentValue != null) {
			// the value exist increment it
			numerotation.put(currentLevel, currentValue + 1);
		} else {
			// init the value
			numerotation.put(currentLevel, 1);
		}
	}
	private static String getCurrentNum() {
		StringBuilder num = new StringBuilder();
		Set<Integer> levels = numerotation.keySet();
		for (Integer level : levels) {
			num.append(numerotation.get(level));
			num.append(".");
		}
		String numstr = num.toString();
		return numstr.substring(0, numstr.length() - 1);
	}
	public static String num(DEDDataEntity dataField) {
		String num = "";
		int level = 1;
		if (dataField != null) {
			level = dataField.getMyLevelInTree() + 1;
		}
		
		if (currentLevel == level) {
			incrementNum();
		} else if (currentLevel < level) {
			addLevel();
		} else if (currentLevel > level) {
			while (currentLevel > level) {
				decrementLevel();
			}
		}
		num = getCurrentNum();
		return num;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
