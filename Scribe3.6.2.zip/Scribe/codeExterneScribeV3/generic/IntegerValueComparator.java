package generic;

import java.util.Comparator;

/**
 * This class is used to compare Integer using their value (used
 * to sort numerotation collection).
 * 
 */
/** From Scribe V4 scripts */

public class IntegerValueComparator implements Comparator<Integer> {

	@Override
	public int compare(Integer arg0, Integer arg1) {
		int result = 0;
		if (arg0 != null && arg1 != null) {
			result = arg0.compareTo(arg1);
		}
		return result;
	}
}
