package generic;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class schema {
	
	private static StringBuffer readFile(String filename) {
		StringBuffer buf = new StringBuffer();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(filename), "ISO-8859-1"));
			String str = null;
			while ((str = in.readLine()) != null) {
				buf.append(str + "\n");
			}
			in.close();
		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return buf;
	}

	public static String getVersion(String schemaName) {
		StringBuffer buffer = readFile(schemaName);
		String version = null;
		int endVersion = -1;
		int beginVersion = -1;
		beginVersion = buffer.indexOf("<xs:schema");
		beginVersion = buffer.indexOf("version=\"", beginVersion);
		if (beginVersion != -1) {
			
			beginVersion = beginVersion + 9;
			endVersion = buffer.indexOf("\"", beginVersion);
			version = buffer.substring(beginVersion, endVersion);

		}
		return version;
	}
	public static void main(String[] args) {
		System.out.println(getVersion("Z:\\Support\\PLEIADES\\CCM11-Dico1.5\\DM923-ImpactsDicoSYS1.5\\DM927-PHR-XCI-7_6-10\\1.6\\phr_on_board_calibration_data.xsd"));

	}

}
