package Pleiades;
import java.util.Locale;
import java.util.TreeMap;

import org.apache.log4j.xml.DOMConfigurator;

import scribe.ded.DEDDictionary;
import scribe.ded.DEDParseException;
import scribe.ded.Localisation;
import scribe.ded.generator.DEDFactory;
import XSImport.parser.Messages;


/*
 * Created on 24 nov. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class test {

	public static void main(String[] args) {
		Messages.setCurrentLocale(new Locale("fr", ""));
		Localisation.setCurrentLocale(new Locale("fr", ""));
		DOMConfigurator.configure("log4j.xml");
		DEDFactory loader = new DEDFactory();
		

		    //String XSD = "Z:\\Support\\PLEIADES\\IMG\\DM-522\\PHRDico\\IMG\\cand3.xsd";
		//String XSD = "Z:\\Support\\PLEIADES\\IMG\\DM-524\\PHRDico\\IMG\\image\\0.1\\image.xsd";	
		//String XSD = "Z:\\Support\\PLEIADES\\RMBillot\\BulletinMadras\\phr_jamming_orbital_data.xsd";
		String XSD = "Z:\\Support\\PLEIADES\\PROG\\Schemas_XML_post_RCP\\PROG\\include\\phr_commun_gml\\gml.xsd";
		//XSD = "Z:\\Support\\PLEIADES\\DICO\\DICO1.1\\SYS\\base\\2.0\\base.xsd";
	XSD="Z:\\Support\\PLEIADES\\RIS\\XCI-0-30\\1.2\\phr_jamming_stations_data.xsd";
	//XSD = "C:\\temp\\testScribe\\phr_orbital_data_nominal.xsd";
		try {
//				loader.loadFileName(args[0]);
				//loader.loadFileName(XSD);
//				loader.loadFileName("Z:\\Support\\PLEIADES\\FRaynaud\\CCC_Dico_V1.1\\DM-0H5-350\\Inline\\phr_orbital_data_predicted.xsd");
				
				//DEDDictionary dictionary = loader.getDictionary();
				
				// DEDDataEntity entity = dictionary.getDataEntityFromEastPath("PHR_JAMMING_STATIONS_DATA.STATION.STATION_COORDINATES.LONGITUDE");
				/*
				System.out.println(entity.getDataUserAttributes());
				System.out.println("-----------------");
				System.out.println(entity.getAttributeCollection());
				*/
				/*
				Map m1 = entity.getAttributeCollection();
				Map m2 = null;
				if (entity.getInheritsFrom() != null) {
				   m2 = entity.getInheritsFrom().getAttributeCollection();
				}

				System.out.println( phrDoc.print(m1, m2, false));
				/*
						
				
				TreeMap types = new TreeMap(dictionary.getModelMap());
				dico.setStyleActiv(true);
				dico.setSource(XSD);
				dico.setAnnexe(false);
				dico.setCurrentFontLevel(1);
				dico.setFullDico(false);
				String res = dico.printTypes(types);
				System.out.println(res);
*/
							

				XSD = "Z:\\Support\\PLEIADES\\CCM0707-Dico1.6.2\\Dicos\\SYS\\image\\1.4\\image.xsd";
				loader.loadFileName(XSD);
				DEDDictionary dictionary = loader.getDictionary();
				TreeMap types = new TreeMap(dictionary.getModelMap());
				dico.setSource(XSD);
				String res = dico.printTypes(types);
				System.out.println(res);
/*
				Collection c = dictionary.getAttributeCollectionByName("ISSUE");
				if (c != null) {
					   Iterator it = c.iterator();
					   while (it.hasNext()) {
					      // Cet attribut est complexe par d�finition
					      DEDAttribute att = (DEDAttribute)it.next();
					      Collection info = att.getAttributeCollectionChildren("ID");
					      if (info != null) {
					         
					         DEDAttribute id = (DEDAttribute)info.toArray()[0];
					         String val = id.getValue();
					         System.out.println("Id = " + val);
					      }
					   }
				}
					         
				DEDDataEntity dataField = dictionary.getDataEntityFromEastPath("PHR_ORBITAL_DATA_PREDICTED.ORBIT.POSITION_SPEED.P");
				
				Map m1 = dataField.getDataUserAttributes();
				Map m2 = null;
				if (dataField.getInheritsFrom() != null) {
				   m2 = dataField.getInheritsFrom().getDataUserAttributes();
				}

				System.out.println(phrDoc.print(m1, m2));
				
				/*
				DEDDataEntity dataField = dictionary.getDataEntityFromEastPath("PHR_ORBITAL_DATA_PREDICTED.EPHEMERIS_DESCRIPTION.START_DATE");
				System.out.println(simpleType.print(dataField));
				*/
				/*
				String doc = "CASE : <br>	SWITCH  &lt;ExpressionElementaire><br> 		{CASE  Constante<br>                      &lt;Instruction><br>                      [BREAK]}*<br>          	<br> 		DEFAULT &lt;Instruction><br> 	END SWITCH<br><br>Avec :<br>	-	&lt;ExpressionElementaire> d�signe un mn�monique de param�tre (param�tre TM re�u ou calcul�, param�tre syst�me, param�tre op�rateur ou param�tre local d�fini pr�c�demment dans le plan). La valeur utilis�e pour un param�tre TM est sa valeur physique si rien n'est pr�cis� ou sa valeur brute si le mn�monique est pr�c�d� du mot cl� RAW. <br>	-	&lt;Instruction> d�signe une des instructions possibles du langage.<br><br><br>CHECK :<br>        CHECK &lt;ExpressionLogique>, hh:mm:ss<br><br>Avec :<br><br>	-	&lt;ExpressionLogique> est d�finie dans la syntaxe de l'instruction IF,<br>	-	Virgule obligatoire entre l'expression logique et le timer.<br><br><br>IF : <br>	IF &lt;ExpressionLogique><br>		THEN &lt;Instruction><br>		[ELSE &lt;Instruction>]<br>	END IF                  <br> <br> Avec : <br>	-	&lt;Instruction> d�signe une des instructions possibles du langage <br>	-	 &lt;ExpressionLogique> = NOT &lt;ExpressionLogique> [&lt;SuiteExpression>]<br>								| &lt;Comparaison> [&lt;SuiteExpression>]<br><br>		&lt;SuiteExpression> = AND &lt;ExpressionLogique> <br>							| OR &lt;ExpressionLogique><br><br>		&lt;Comparaison> = 	(&lt;ExpressionLogique>)<br>			|				 &lt;Terme> &lt;OperateurComp> &lt;Terme><br><br>		&lt;OperateurComp> =  	&lt; | > | >= | &lt;= | &lt;> | =<br><br>	-	&lt;Terme> d�signe une valeur (entier, flottant, cha�ne de caract�res) ou un m�monique de param�tre (param�tre TM re�u ou calcul�, param�tre syst�me, param�tre op�rateur ou param�tre local d�fini pr�c�demment dans le plan). La valeur utilis�e pour un param�tre TM est sa valeur physique si rien n'est pr�cis� ou sa valeur brute si le mn�monique est pr�c�d� du mot cl� RAW. <br><br><br>LOAD_PLAN :<br>	LOAD_PLAN 'cheminAccesRelatifAuPlan.pln'<br><br>Avec :<br>	Quotes obligatoires pour entourer le nom du plan<br><br><br>LOG :<br>	LOG ('Gravite' 'Msg')<br><br>Avec :<br>	-	Parenth�ses obligatoires<br>	-	Quotes obligatoires autour de la gravite et du message<br><br><br>NONE :<br>	Instruction sans param�tre<br><br>PAUSE :<br>	PAUSE ('Msg' [, 'Msg']* )<br><br>Avec : <br>	-	Parenth�ses obligatoires<br>	-	Quotes obligatoires autour des messages<br>	-	Virgule pour mat�rialiser les retours � la ligne dans la fen�tre d'affichage<br><br>PRINTF :<br>	PRINTF ('Fichier' 'Msg')<br><br>Avec :<br>	-	Parenth�ses obligatoires,<br>	-	Quotes obligatoires pour le nom du fichier et le message.<br><br>SET_MODE : <br>	Deux instruction sont possibles SET_MODE NORMAL ou SET_MODE EXPEDITED<br><br>SET :<br>	SET &lt;Param> TO &lt;Valeur><br><br>Avec :<br>	-	&lt;Param> est un m�monique de param�tre local ou de param�tre TM re�u ou calcul�,<br>	-	&lt;Valeur> est <br>			o	un entier, un flottant ou une cha�ne de caract�res,<br>			o	un mn�monique de param�tre TM re�u ou calcul�, de param�tre syst�me, de param�tre op�rateur ou de param�tre local d�fini pr�c�demment dans le plan (par une instruction SET pr�c�dente).<br><br><br>SET_OPERATOR :<br>	SET_OPERATOR &lt;ParamOp> TO &lt;Valeur> <br><br>Avec :<br>	-	&lt;ParamOp> est un m�monique de param�tre op�rateur,<br>	-	&lt;Valeur> est <br>			o	un entier, un flottant ou une cha�ne de caract�res,<br>			o	un mn�monique de param�tre TM re�u ou calcul�, de param�tre syst�me ou de param�tre local d�fini pr�c�demment dans le plan.<br><br><br>STOP :<br>	instruction sans param�tre.<br><br><br>WAIT :<br>	WAIT hh:mn:ss<br><br><br>WAIT_PACKET :<br>	WAIT_PACKET &lt;Numero_APID><br><br>Avec : <br>	-	&lt;Numero_APID> est la valeur hexad�cimale d'un APID ou le mn�monique d'un paquet TM.<br><br><br>WHILE :<br>	WHILE  &lt;ExpressionLogique><br>		DO  &lt;Instruction><br>	END WHILE                  <br><br>Avec : <br>	-	&lt;Instruction> d�signe une des instructions possibles du langage,<br>	-	&lt;ExpressionLogique> est d�finie dans la syntaxe de l'instruction IF.<br><br>�T<br><br><b>STRUCTURE DES TC</b><br>";
				System.out.println("En entree");
				System.out.println(doc);
				System.out.println("En sortie");
				System.out.println(phrDoc.indent(doc));
				*/
			} catch (DEDParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}
}
