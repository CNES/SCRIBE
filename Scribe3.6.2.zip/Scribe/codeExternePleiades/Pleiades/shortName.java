/*
 * Created on 4 nov. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package Pleiades;

import java.util.HashMap;
import java.util.Map;

import scribe.ded.DEDDataEntity;

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class shortName {
	
	private static Map table = new HashMap();
	private static boolean actif = false;
	private static String IFName = "";
	
	public static void clear() {
		table.clear();	
	}
	public static void on() {
		actif = true;
	}
	public static void off() {
		actif = false;
	}
	public static void setIF(String name) {
		IFName = name;
	}
	public static String get(String longName) {

		if (!actif) return longName;
		
		String res = "LINK_" + IFName ;
		
		if (!table.containsKey(longName)) {
			table.put(longName,new Integer(table.size()));
		}
		
		res += ((Integer)table.get(longName)).toString();
		return res;
		
	}
	public static String getHtmlLinkOn(DEDDataEntity dataField, String nom, int index) {
		if (!actif) return dataField.getHtmlLinkOn(nom,index);
		String res = "<a href=\"#" + get(dataField.getEastPath() + new Integer(1000 + index)) + "\">" + nom + "</a>";
		return res;
	}
	
	public static String getHtmlAnchor(DEDDataEntity dataField,int index) {
		if (!actif) return dataField.getHtmlAnchor(index);
		String res = "<a name=\"" + get(dataField.getEastPath() + new Integer(1000 + index)) + "\">";
		return res;
	}

}
