/*
 * Created on 3 nov. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package Pleiades;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import scribe.ded.DEDComponent;
import scribe.ded.DEDCompositeType;
import scribe.ded.DEDDataEntity;

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class dico {
	private static Map dicos = new TreeMap() ;
	private static Map nextDataFieldList = new TreeMap();
	private static Map currentDataFieldList = new TreeMap();
	private static Map currentDataModelList = new TreeMap();
	private static Map usedDataModelList = new TreeMap();
	private static List printedTypes = new ArrayList();
	private static int currentFontLevel = 2;
	private static boolean styleActiv = true;
	private static boolean annexe = false;
	private static String dicoId = "";
	private static String sourceId = "";
	// Si on imprime tous les th�mes du dictionnaire
	// il ne faut pas imprimer les th�mes inclus
	// sinon redite
	private static boolean fullDico = true;
	
	
	private static String printStyle() {
		String res = "";
		if (!annexe) {
			res += "<h" + new Integer(currentFontLevel) + ">";
			if (styleActiv) {
				//res += "<font size=2 color=\"mediumblue\">";
				res += "<font color=\"mediumblue\">";
			}
		}
		else {
			res = "<p class='annexe " + new Integer(currentFontLevel) + "'>";
		}
		
		System.out.println(res);
		return res;
	}
	private static String printEndStyle() {
		String res = "";
		if (!annexe) {
			if (styleActiv) {
				res += "</font>";
			}
			res += "</h" + new Integer(currentFontLevel) + ">";
		}
		else {
			res = "</p>";
		}
		return res;
	}
	private static String printName(DEDDataEntity dataField, String path) {
		// Copie de X_Nom
		String nom = "";
		if ( dataField.getInheritsFrom() != null ) {
			nom = dataField.getName();
		}
		else {
			if (dataField.isComposite()) {
				//Sauf si le composite est vide !
				DEDCompositeType composite = (DEDCompositeType)dataField.getEntityType();
				if (composite.getComponents().size() != 0) {
					nom = dataField.getName();
					if (dataField.isAnonymous()) {
			            if (dataField.isChoice()) nom = "...|...";
			            else nom = "...";
			         }
					//if (dataField.getType().equals("CHOICE_TYPE")) nom = "...|...";
					// ce dataField ne peut avoir de EASTPATH car il n'existe que par
					// sa pr�sence dans la d�finition d'un type
					// Il faut se baser sur un path externe
					//nom = dataField.getHtmlLinkOn(nom,1);
					
					String linkOn = path + ":" + nom ;
					
					nextDataFieldList.put(linkOn, dataField);
					nom = "<a href=\"#"+ shortName.get(linkOn) +  "\">" + nom + "</a>";
					
				}
				else nom = dataField.getName();
			}
			else nom = dataField.getName();
		}
		
		return nom;
	}
	private static String printOccurrence (DEDComponent component) {
		// Inspire de X_Occurrence
		String occurrence = "";
		String nbOcc = "";
		String nbMin = "";
		nbOcc=component.getMaxValue();
		nbMin=component.getMinValue();
		
		if (nbOcc.equals("-1")) occurrence = " * n";
		else if (nbOcc.equals("1")) occurrence = "";
		else {
			
			if (nbOcc.equals(nbMin)) {
				occurrence = " * " + nbOcc;
			}
			else 
				occurrence = " * [" + nbMin + " .. " + nbOcc + "]" ;
		}
		
		return occurrence;
	}
	private static String printOptionalite (DEDComponent component) {
		if (component.getMinValue().equals("0")) {
			return "O"; // Pour Optionnel
		}
		return "R"; // Pour Requis
	}
	
	private static String getLocalName(DEDDataEntity type) {
		
		String fullName = type.getName();
		return localName.get(fullName);
	}
	
	private static String getPrefix(DEDDataEntity type) {
		
		String fullName = type.getName();
		int pos = fullName.lastIndexOf(":");
		if (pos != -1) return fullName.substring(0,pos);
		else return "";
		
	}
	private static String printType(DEDDataEntity dataField) {
		DEDDataEntity type = null;
		String description = "";
		
		type =  dataField.getInheritsFrom();
//		Verrue pour Scribe V3.1.3
		if (type != null) {
			if (type.getName().indexOf("http://www.w3.org/2001/XMLSchema:") != -1) {
				return simpleType.print(dataField);
			}
		}
		if ( type == null ) {
			if (dataField.isComposite()) {
//				Sauf si le composite est vide !
				DEDCompositeType composite = (DEDCompositeType)dataField.getEntityType();
				if (composite.getComponents().size() != 0) {
					if (dataField.isChoice()) return "Choix";
					return "Structure";
				}
				else return "<font color=\"red\">ind�fini</font>";
			}
			else return simpleType.print(dataField);
			
		}
		else {
			boolean A = (getPrefix(type).indexOf(dicoId) != -1);
			boolean B = getPrefix(type).equals("");
			boolean C = dicoId.equals("local");
			boolean D = A || (B && C);
			
			if (!D)
				usedDataModelList.put(type.getName(),type);
			return "<a href=\"#" + shortName.get(type.getName()) + "\">" +
			getLocalName(type) + "</a>";
		}
	}
	private static String printComplexType(String ancre, String typeName, String path, DEDDataEntity type) {
		String res = "";
		res += printStyle() + ancre + typeName + printEndStyle();
		DEDCompositeType composite = (DEDCompositeType)type.getEntityType();
		
		res += "<b>Description : </b>" + simpleType.shortDefinition(type);
		res += simpleType.definition(type);
		res += simpleType.printPattern(type);
		res +=  simpleType.printAttributs(type)+ "<br>";
		
		res += "<table border=\"1\">";
		res += "<tr><th>Nom</th><th>Type</th><th>Optionnel/Requis</th><th>Description<th></tr>";
		
		ArrayList components = composite.getComponents();
		ArrayList children = type.getChildrenList();
		DEDComponent component = null;
		DEDDataEntity dataField = null;
		int size = components.size();
		for (int i = 0; i < size; i++) {
			component = (DEDComponent)components.get(i);
			dataField = (DEDDataEntity)children.get(i);
			res += "<tr>";
			
			res += "<td>" + printName(dataField, path) + printOccurrence(component) + "</td>";
			
			res += "<td align=\"center\">" + printType(dataField) + "</td>";
			
			res += "<td align=\"center\">" + printOptionalite(component) + "</td>";
			res += "<td>" + simpleType.shortDefinition(dataField)+
			simpleType.definition(dataField) + 
			simpleType.printPattern(dataField) +
			simpleType.storeAttribut(dataField) + "</td>";
			
			res += "</tr>";
			
		}
		
		res += "</table>";
		
		res += simpleType.printStoredAttributs();
		
		return res;
	}
	
	private static String printSimpleType(String ancre, String typeName, DEDDataEntity value) {
		String res = "";
		res += printStyle() + ancre + typeName + printEndStyle();
		res += "<b>Type : </b>" + simpleType.print(value) + "<br>";
		res += "<b>Description : </b>" + simpleType.shortDefinition(value);
		res += simpleType.definition(value);
		res += simpleType.printPattern(value);
		res +=  simpleType.printAttributs(value);
		return res;
	}
	private static String printRecap(String dicoName, Map types) {
		String res = "";
		
		
		// if (!dicoName.equals(dicoId))
		if (dicoName.indexOf(dicoId) == -1) {
			return "";
		}
		
		if (dicoName.equals("local")) dicoName += " " + sourceId;
		res += printStyle() + " Dictionnaire " + dicoName + printEndStyle();
		currentFontLevel++;
		Iterator it = types.entrySet().iterator();
		res += "<table>";
		while (it.hasNext()) {
			Map.Entry ent = (Map.Entry)it.next();
			String key = (String) ent.getKey();
			String name = "";
			if (dicoName.startsWith("local")) name = key;
			else name = dicoName + ":" + key;
			//String ancre = "<a name=\"" + shortName.get(name) + "\">";
			res += "<tr>";
			DEDDataEntity value = (DEDDataEntity)ent.getValue();
			if (value.isComposite()) {
				res += "<td> complexe </td>";
			}
			else {
				res += "<td> simple </td>";
			}
			res += "<td>"+shortName.get(name)+"</td>";
			res += "<td>"+value.getShortDefinition()+"</td>";
			res += "</tr>";
		}
		res += "</table>";
		return res;
	}
	private static String printDico(String dicoName, Map types) {
		String res = "";
		
		if (dicoName.toLowerCase().indexOf(dicoId.toLowerCase()) == -1) {
			return "";
		}
		
		if (dicoName.equals("local")) dicoName += " " + sourceId;
		res += printStyle() + " Dictionnaire " + dicoName + printEndStyle();
		currentFontLevel++;
		Iterator it = types.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry ent = (Map.Entry)it.next();
			String key = (String) ent.getKey();
			printedTypes.add(key);
			String name = "";
			if (dicoName.startsWith("local")) name = key;
			else name = dicoName + ":" + key;
			String ancre = "<a name=\"" + shortName.get(name) + "\">";
			DEDDataEntity value = (DEDDataEntity)ent.getValue();
			if (value.isComposite()) {
				res += printComplexType(ancre , key, name, value);
			}
			else {
				res += printSimpleType(ancre , key, value);
				
			}
		}
		//currentFontLevel--;
		// Impression des structures induites
		if (!nextDataFieldList.isEmpty())
			res += printStyle() + "Structures induites" + printEndStyle();
		currentFontLevel++;
		while (!nextDataFieldList.isEmpty()) {
			
			currentDataFieldList.clear();
			currentDataFieldList.putAll(nextDataFieldList);
			nextDataFieldList.clear();
			it = currentDataFieldList.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry e = (Map.Entry)it.next();
				String key = (String)e.getKey();
				if (!printedTypes.contains(key)) {
					printedTypes.add(key);
					
					String ancre = "<a name=\"" + shortName.get(key) + "\">";
					DEDDataEntity value = (DEDDataEntity)e.getValue();
					if (value.isComposite()) {
						res += printComplexType(ancre , localName.get(key), key, value);
					}
					else {
						res += printSimpleType(ancre , localName.get(key), value);
						
					}
					res += "<br>";
				}
			}
		}
		currentFontLevel--;
		// Impression des types utilis�s
		if (!fullDico) {
			if (!usedDataModelList.isEmpty()) 
				res += printStyle() + "Types utilis�s" + printEndStyle();
			
			currentFontLevel++;
			while (!usedDataModelList.isEmpty()) {
				currentDataModelList.clear();
				currentDataModelList.putAll(usedDataModelList);
				usedDataModelList.clear();
				it = currentDataModelList.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry e = (Map.Entry)it.next();
					String key = (String)e.getKey();
					
					
					String ancre = "<a name=\"" + shortName.get(key) + "\">";
					DEDDataEntity value = (DEDDataEntity)e.getValue();
					if (value.isComposite()) {
						res += printComplexType(ancre , key, "", value);
					}
					else {
						res += printSimpleType(ancre , key, value);
						
					}
					res += "<br>";
				}
			}
			
		}
		
		return res;
	}
	
	private static void tri(String key, DEDDataEntity value) {
		String nom = key;
		String dico = "local";
		int pos = nom.lastIndexOf(":");
		if (pos != -1) {
			dico = nom.substring(0,pos);
			nom = nom.substring(pos+1);
		}
		Map m = (Map)dicos.get(dico);
		if (m != null) {
			m.put(nom,value);
			dicos.remove(dico);
			dicos.put(dico,m);
		}
		else {
			m = new TreeMap();
			m.put(nom,value);
			dicos.put(dico, m);
		}
	}
	public static String printTypes(Map types) {
		String res = "";
		dicos.clear();
		
		if (types != null) {
			Set s = types.entrySet();
			Iterator i = s.iterator();
			//		 Parcours pour tri
			while (i.hasNext()) {
				Map.Entry e =  (Map.Entry)i.next();
				String key = (String) e.getKey();
				DEDDataEntity value = (DEDDataEntity)e.getValue();
				if (!key.equals("EOF")) {
					tri (key, value);
				}
			}
		}
//		Parcours pour impression
		Set s = dicos.entrySet();
		Iterator i = s.iterator();
		
		while (i.hasNext()) {
			Map.Entry e =  (Map.Entry)i.next();
			String key = (String)e.getKey();
			Map m = (Map) e.getValue();
			res += printDico(key,m);
			
		}
		return res;
	}
	
	public static String printRecap(Map types) {
		String res = "";
		dicos.clear();
		
		if (types != null) {
			Set s = types.entrySet();
			Iterator i = s.iterator();
			//		 Parcours pour tri
			while (i.hasNext()) {
				Map.Entry e =  (Map.Entry)i.next();
				String key = (String) e.getKey();
				DEDDataEntity value = (DEDDataEntity)e.getValue();
				if (!key.equals("EOF")) {
					tri (key, value);
				}
			}
		}
//		Parcours pour impression
		Set s = dicos.entrySet();
		Iterator i = s.iterator();
		
		while (i.hasNext()) {
			Map.Entry e =  (Map.Entry)i.next();
			String key = (String)e.getKey();
			Map m = (Map) e.getValue();
			res += printRecap(key,m);
			
		}
		return res;
	}
	
	public static String printSimpleTypes(Map types) {
		String res = "";
		dicos.clear();	
		if (types != null) {
			Set s = types.entrySet();
			Iterator i = s.iterator();
			//		 Parcours pour tri
			while (i.hasNext()) {
				Map.Entry e =  (Map.Entry)i.next();
				String key = (String) e.getKey();
				DEDDataEntity value = (DEDDataEntity)e.getValue();
				if (!value.isComposite() && !key.equals("EOF")) {
					tri (key, value);
				}
			}
		}
		//		 Parcours pour impression
		Set s = dicos.entrySet();
		Iterator i = s.iterator();
		
		while (i.hasNext()) {
			Map.Entry e =  (Map.Entry)i.next();
			String key = (String)e.getKey();
			Map m = (Map) e.getValue();
			res += printDico(key,m);
			
		}
		return res;
		
	}
	
	
	public static void setCurrentFontLevel(int currentFontLevel) {
		dico.currentFontLevel = currentFontLevel;
	}
	
	public static void setStyleActiv(boolean styleActiv) {
		dico.styleActiv = styleActiv;
	}
	
	public static void setAnnexe(boolean annexe) {
		dico.annexe = annexe;
	}
	
	
	public static void setSource(String source) {
		int pos = source.lastIndexOf(".");
		if (pos != -1) source = source.substring(0,pos);
		
		int pos1 = source.lastIndexOf("/");
		int pos2 = source.lastIndexOf("\\");
		if ((pos1 != -1) && (pos2 != -1)) {
			// on prend le max des 2
			if (pos1 > pos2) pos = pos1;
			else pos = pos2;
		}
		else if (pos1 != -1) pos = pos1 + 1;
		else if (pos2 != -1) pos = pos2 + 1;
		else pos = 0;
		
		dicoId = source.substring(pos,source.length());
		
		// Verrue tant que Scribe ne sait pas r�cup�rer le targetNamespace
		//if (dicoId.startsWith("phr_commun")) {
		// un theme du dico a la caract�ristique d'avoir
		// son nom dans le chemin et en tant que fichier
		//if (source.substring(0,pos).indexOf(dicoId) == -1) {
		//	sourceId = dicoId;
		//	dicoId = "local";
		//}
	}
	/**
	 * @param fullDico The fullDico to set.
	 */
	public static void setFullDico(boolean fullDico) {
		dico.fullDico = fullDico;
	}
}
