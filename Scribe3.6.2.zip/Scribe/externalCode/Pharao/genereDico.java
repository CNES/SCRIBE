package Pharao;
import scribe.ded.*;
import java.util.*;
import java.io.*;

/*
 * Created on 21 sept. 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author LarzulB
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class genereDico {
	private static FileWriter file;
	private static void println(String line) {
		try {
			file.write(line);
		}
		catch (IOException e) {
			System.out.println(line);
		}
	}
	
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java genereDico [input file] [output file]");
			System.exit(0);
		}
		String uri = args[0];
		String out = args[1];
		int inc = 1;
		DEDLoader loader = new DEDLoader();
		DEDDictionary dictionary = new DEDDictionary();
		
		try {
			loader.loadFileName(uri);
		}
		catch (DEDParseException e) {
			return;
		}
		try {
			file = new FileWriter(out);
		}
		catch (IOException e) {
			System.out.println("Cannot create " + out);
			return;
		}

		dictionary = loader.getDictionary();
		Map TableauPharao = PaquetsPharao.parcourirDED(dictionary);

		Map triage = new TreeMap(TableauPharao);
		Set LeTableauFinal = triage.entrySet();

		Iterator ite = LeTableauFinal.iterator();
		boolean first = true;

		println("<HTML>\n<BODY>\n<TABLE border=\"1\">\n");
		while (ite.hasNext()) {
			Map.Entry entree = (Map.Entry) ite.next();
			LignePharao UneLigne = (LignePharao) entree.getValue();
			if (first){
				println(UneLigne.printHeaderHTML());
				first = false;
			}
			println(UneLigne.printHTML());
		}
		println("</TABLE>\n</BODY>\n</HTML>");
		
		try {
			file.close();
		}
		catch (IOException e) {
			System.out.println("Cannot close " + out);
		}
	}
}
