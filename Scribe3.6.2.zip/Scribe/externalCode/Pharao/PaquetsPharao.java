/*
 * Created on 20 sept. 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package Pharao;
import scribe.ded.*;
import java.util.*;

/**
 * @author LarzulB
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PaquetsPharao {
	private static DEDDictionary dictionary;
	private static Map TableauPharao = new HashMap();

	// public PaquetsPharao() {}

	private static String getDiscriminantValues(String name, String inf, String sup) {
		Map datamap = dictionary.getDataFieldMap();
		String result = "";

		int index;
		boolean dedans = false;

		DEDDataEntity dde = (DEDDataEntity) datamap.get(name);
		Map modelmap = dictionary.getModelMap();


		DEDDataEntity from = (DEDDataEntity) modelmap.get(dde.getInheritsFromDataName());
		String tousLesTypes = from.getRepresentational();
		while ((index = tousLesTypes.indexOf("value : ")) > 0) {
			int index2 = tousLesTypes.indexOf("convention : ");
			String valeur = tousLesTypes.substring(index+8,index2-1 );
			if (valeur.equals(inf))
				dedans = true;
			if (dedans)
				if (result.equals(""))
					result = valeur;
				else
					result = result + ", " + valeur;
			if (valeur.equals(sup))
				break;
			tousLesTypes = tousLesTypes.substring(index2+10,tousLesTypes.length());
		}
		return result;
	}
	private static String concat(String chaine1, String chaine2) {
		String Result = "";
		String temp1 = chaine1;
		String temp2 = chaine2;
		int index1,index2;


		while ((index1 = temp1.indexOf(", "))>0) {
			String sousChaine = temp1.substring(0,index1);
			while ((index2 = temp2.indexOf(", "))>0) {
				String sousChaine1 = temp2.substring(0,index2);
				if (Result.equals(""))
					Result=Result+sousChaine+"."+sousChaine1.trim();
				else
					Result=Result+", "+sousChaine+"."+sousChaine1.trim();
				temp2 = temp2.substring(index2+1,temp2.length());
			}
			String sousChaine1 = temp2;
			if (Result.equals(""))
				Result=Result+sousChaine+"."+sousChaine1.trim();
			else
				Result=Result+", "+sousChaine+"."+sousChaine1.trim();
			temp1 = temp1.substring(index1+1,temp1.length());
		}
		String sousChaine = temp1;
	   while ((index2 = temp2.indexOf(", "))>0) {
				String sousChaine1 = temp2.substring(0,index2);
				if (Result.equals(""))
					Result=Result+sousChaine+"."+sousChaine1.trim();
				else
					Result=Result+", "+sousChaine+"."+sousChaine1.trim();
				temp2 = temp2.substring(index2+1,temp2.length());
			}
			String sousChaine1 = temp2;
			if (Result.equals(""))
				Result=Result+sousChaine+"."+sousChaine1.trim();
			else
				Result=Result+", "+sousChaine+"."+sousChaine1.trim();
		return(Result);
	}


	private static String result(DEDDataEntity dataField) {

		String result= "";
		Map conditionMap = new HashMap();

		List conditions = dataField.getConditionsList();
		Iterator it = conditions.iterator();
		// Remplir la structure avec les conditions
		String functionID = "*";
		String functionMode = "";
		String Status = "";
		String Paquet = "";
		String functionOrModeID = "";
		boolean PaquetP = false;
		boolean DejaPaquet = false;
		boolean DejaFunctionMode = false;
		boolean DejaFunctionID = false;
		boolean DejaStatus = false;
		boolean DejaFunctionOrModeID = false;
		boolean ApresLeAND = false;
		int num = 0;

		while (it.hasNext()) {
			num ++;
			String buffer = (String) it.next();

			if (!DejaPaquet) {

				int indexAnd;
				while ((indexAnd = buffer.indexOf(" AND ")) >0) {
					ApresLeAND = true;

					String intervalle = buffer.substring(0,indexAnd);

					int index = intervalle.indexOf('[');
					//
					// Modif � cause des parenth�ses dans les conditions
					// Arnaud le 31/07/03
					//
					String EastPath;
					if (intervalle.indexOf('(') == 1)
						EastPath = intervalle.substring(2,index);
					else
						EastPath = intervalle.substring(1,index);
					// fin de la modif


					index = intervalle.indexOf('[');
					int index1 = intervalle.indexOf("..");
					int index2 = intervalle.indexOf(']');
					String borneInf = intervalle.substring(index+1,index1);
					String borneSup = intervalle.substring(index1+2,index2);

					if ((!DejaFunctionMode) && (index = intervalle.indexOf("FUNCTION_OR_MODE_OR_ACTIVITY")) > 0) {
						if (borneSup.equals(borneInf))
							functionMode = borneInf;
						else
							functionMode = getDiscriminantValues(EastPath,borneInf,borneSup);
						DejaFunctionMode=true;
					}

					if ((!DejaFunctionID) && (index = intervalle.indexOf("FUNCTION_ID")) > 0) {
						if (borneSup.equals(borneInf))
							functionID = borneInf;
						else
							functionID = getDiscriminantValues(EastPath,borneInf,borneSup);
						DejaFunctionID=true;
					}

					if ((!DejaStatus) && (index = intervalle.indexOf("FUNCTION_STATUS")) > 0) {
						if (borneSup.equals(borneInf))
							Status = borneInf;
						else
							Status = getDiscriminantValues(EastPath,borneInf,borneSup);
						DejaStatus=true;
					}
					if ((!DejaFunctionOrModeID) && (index = intervalle.indexOf("GENERAL_FUNCTION_OR_MODE_ID_STD")) > 0) {
						if (borneSup.equals(borneInf))
							functionOrModeID = borneInf;
						else
							functionOrModeID = getDiscriminantValues(EastPath,borneInf,borneSup);
						DejaFunctionOrModeID=true;
					}
					if ((!DejaPaquet) && (index = intervalle.indexOf("PACKET_ID")) > 0) {
						if (borneSup.equals(borneInf))
							Paquet = borneInf;
						else
							Paquet = getDiscriminantValues(EastPath,borneInf,borneSup);
						DejaPaquet=true;
					}
					buffer = buffer.substring(indexAnd,buffer.length());
				}





				///////////////////////////
				// PAS DE AND
				///////////////////////////


				String intervalle = buffer;
				int index = intervalle.indexOf('[');
				//
				// Modif � cause des parenth�ses dans les conditions
				// Arnaud le 31/07/03
				//


				String EastPath;
				if (intervalle.indexOf('(') == 1) {
					// Modif B�a le 3/10/2003
					//EastPath = intervalle.substring(2,index);
					EastPath = intervalle.substring(1,index);
				}
				else {
					// Modif B�a le 3/10/2003
					//EastPath = intervalle.substring(1,index);
					EastPath = intervalle.substring(0,index);
				}
				if (ApresLeAND) {

					EastPath = intervalle.substring(5,index);

				}
				// fin de la modif

				index = intervalle.indexOf('[');
				int index1 = intervalle.indexOf("..");
				int index2 = intervalle.indexOf(']');
				String borneInf = intervalle.substring(index+1,index1);
				String borneSup = intervalle.substring(index1+2,index2);


				 if ((!DejaFunctionMode) && (index = intervalle.indexOf("FUNCTION_OR_MODE_OR_ACTIVITY")) > 0) {
						if (borneSup.equals(borneInf))
							functionMode = borneInf;
						else
							functionMode = getDiscriminantValues(EastPath,borneInf,borneSup);
						DejaFunctionMode=true;
					}

				if ((!DejaFunctionID) && (index = intervalle.indexOf("FUNCTION_ID")) > 0) {
					if (borneSup.equals(borneInf))
						functionID = borneInf;
					else
						functionID = getDiscriminantValues(EastPath,borneInf,borneSup);
					DejaFunctionID=true;
				}

				if ((!DejaStatus) && (index = intervalle.indexOf("FUNCTION_STATUS")) > 0) {
					if (borneSup.equals(borneInf))
						Status = borneInf;
					else
						Status = getDiscriminantValues(EastPath,borneInf,borneSup);
					DejaStatus=true;

				}
				if ((!DejaFunctionOrModeID) && (index = intervalle.indexOf("GENERAL_FUNCTION_OR_MODE_ID_STD")) > 0) {

					if (borneSup.equals(borneInf))
						functionOrModeID = borneInf;
					else
						functionOrModeID = getDiscriminantValues(EastPath,borneInf,borneSup);
					DejaFunctionOrModeID=true;
				}
				if ((!DejaPaquet) && (index = intervalle.indexOf("PACKET_ID")) > 0) {
					if (borneSup.equals(borneInf))
						Paquet = borneInf;
					else
						Paquet = getDiscriminantValues(EastPath,borneInf,borneSup);
					DejaPaquet=true;
				}


			}


		}

		if (num == 0)
			return ("All Packets");


		if (DejaStatus) {
			return (concat(concat(Paquet,functionID),Status));

		}
		if (DejaFunctionOrModeID) {
			return(concat(Paquet,functionOrModeID));
		}
		if (DejaFunctionMode) {
			return (concat(Paquet,functionMode));

		}
		return Paquet;



	}

	private static void parcourirNiveau(List liste) {
		if (liste != null) {
			Iterator it = liste.iterator();
			while (it.hasNext()) {
				DEDDataEntity entity = (DEDDataEntity) it.next();
				if (entity.getChildrenList()!=null) {
					parcourirNiveau(entity.getChildrenList());
				}
				else {
					LignePharao UneLigne = new LignePharao();
					ArrayList al = entity.getAliases();
					DEDAlias alias;

					if (al != null) {
						int size = al.size();
						if ( size >= 2 ) {
							alias = (DEDAlias)al.get(1);
							UneLigne.setUGBName(alias.getName());
						}
						if ( size >= 3 ) {
							alias = (DEDAlias)al.get(2);
							UneLigne.setICDName(alias.getName());
						}
						if ( size >= 1 ) {
							alias = (DEDAlias)al.get(0);
							UneLigne.setSTBName(alias.getName());
						}

					}

					DEDDataEntity dataDef;
					String typeString = "";
					if ( entity.getInheritsFrom() != null ) {
						dataDef = entity.getInheritsFrom();
					}
					else {
						dataDef = entity;
					}

					if (dataDef.isComposite()) typeString = "Composite";
					else if (dataDef.isInteger()) {
						Object obj = dataDef.getEntityType();
						DEDIntegerType data = (DEDIntegerType)obj;
						typeString =  "Integer[" + data.getMinValue() + " .. " + data.getMaxValue() + "]";
					}
					else if (dataDef.isReal()) typeString = "Real ";
					if (dataDef.isEnumerated()) {
						Object obj = dataDef.getEntityType();
						DEDEnumeratedType data = (DEDEnumeratedType)obj;
						ArrayList arl = data.getEnumerations();
						DEDEnumeration anEnum = null;
						int size = arl.size();
						char c = 10;

						for( int i=0; i<size; i++ ) {
							anEnum = (DEDEnumeration)arl.get(i);
							typeString = typeString + anEnum.getValue() + "(" + anEnum.getConvention() + ") "+ "#ARN#";
						}
					}
					UneLigne.setOASISName(entity.getName());
					UneLigne.setType(typeString);
					UneLigne.setDefinition(entity.getDefinition());
					UneLigne.setACESName(entity.getShortDefinition());
					UneLigne.setPacket(result(entity));

					String key = UneLigne.getSTBName();

					if (TableauPharao.containsKey(key)) {
						LignePharao LaLigne = (LignePharao)TableauPharao.remove(key);
						UneLigne.addPacket(LaLigne.getPacket());
					}
					TableauPharao.put(key,UneLigne);

				}
			}
		}
	}



   public static Map parcourirDED(DEDDictionary dico) {
   	   dictionary = dico;
	   parcourirNiveau(dico.getChildrenDataEntityList());
	   return TableauPharao;
   }
}
