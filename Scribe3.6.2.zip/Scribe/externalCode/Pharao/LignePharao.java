package Pharao;
/*
 * Created on 20 sept. 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author LarzulB
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class LignePharao {
	String STBName;
	String OASISName;
	String ACESName;
	String ICDName;
	String UGBName;
	String Definition;
	String Type;
	String Packet;

	public LignePharao() {
	  STBName = "";
	  OASISName = "";
	  ACESName = "";
	  ICDName = "";
	  UGBName = "";
	  Definition = "";
	  Type= "";
	  Packet = "";
	}

	public void setSTBName(String str)
	{
	  STBName = str;
	}

	public String getSTBName() {
	  if (STBName.equals(""))
		return OASISName;
	  else
		return STBName;
	}

	public void setOASISName(String str)
	{
	  OASISName = str;
	}

	public String getOASISName() {
		return OASISName;
	}

	public void setICDName(String str)
	{
	  ICDName = str;
	}

	public String getICDName() {
	  return ICDName;
	}

	public void setUGBName(String str)
	 {
	   UGBName = str;
	 }

  public String getUGBName() {
	   return UGBName;
	 }

	 public void setACESName(String str)
		{
		  if (str != null)
			ACESName = str;
		}

  public String getACESName() {

		  return ACESName;
		}

	public void setDefinition(String str)
	{
	  Definition = str;
	}

	public String getDefinition() {
	  return Definition;
	}

	public void setType(String str)
	{
	  Type = str;
	}

	public String getType() {
	  return Type;
	}

	public void addPacket(String str)
	{
	  Packet = Packet + ", " + str;
	}

	public void setPacket(String str)
	{
	  Packet =  new String(str);
	}

	public String getPacket() {
	  return Packet;
	}
	public String printHeaderHTML() {
	   return("<TR>\n<TD>STB M&S Name</TD><TD>OASIS Name</TD><TD>ACES Name</TD><TD>UGB ICD Name</TD><TD>Other Eqpts ICD Name</TD><TD>Definition</TD><TD>Type</TD><TD>Packet</TD>\n</TR>\n");
      
	}
	public String printHTML() {
	String Result = "<TR>";
	Result = Result + "<TD>" + getSTBName() + "</TD>";
	Result = Result + "<TD>" + getOASISName() + "</TD>";
	Result = Result + "<TD>" + getACESName() + "</TD>";  
	Result = Result + "<TD>" +getUGBName() + "</TD>";
	Result = Result + "<TD>" +getICDName() + "</TD>";
	Result = Result + "<TD>" +getDefinition() + "</TD>";
	Result = Result + "<TD>" +getType().replaceAll("#ARN#","<br>") + "</TD>";
	Result = Result + "<TD>" +getPacket().replaceAll(" , ","<br>") + "</TD>";
	Result = Result + "</TR>";
	return Result;

   }
}
