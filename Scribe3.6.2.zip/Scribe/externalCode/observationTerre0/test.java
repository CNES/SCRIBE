/*
 * Created on 14 oct. 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package observationTerre;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import scribe.ded.DEDDataEntity;
import scribe.ded.DEDDictionary;
import scribe.ded.DEDEnumeratedType;
import scribe.ded.DEDEnumeration;
import scribe.ded.DEDLoader;
import scribe.ded.DEDParseException;

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class test {

	public static void main(String[] args) {
		DEDLoader loader = new DEDLoader();
		DEDDictionary dictionary = new DEDDictionary();
		String uri = "";
		try {
			loader.loadFileName(args[0]);
		}
		catch (DEDParseException e) {
			return;
		}
		dictionary = loader.getDictionary();
		/*
		List l = dictionary.getChildrenDataEntityList();
		String res;
		res = IF.ordonnancementDesBlocs(l);
		System.out.println(res);
		res = IF.listeDesBlocs(l);
		System.out.println(res);
		res = IF.conditionsDesBlocs(l);
		System.out.println(res);
		
		List liste = new ArrayList();
		liste.add("DATE");
		liste.add("DATE_H");
		liste.add("DATE_H_MS");
		liste.add("HEURE_MS");
		liste.add("JJ_CNES_MS");
		
		
		IF.setLesTypesConnus(liste);
	
		IF.initDescriptionChampCourant();
		IF.initTypeChampCourant();
		IF.setComplementInfo(m);
	    IF.noterCaracteristiquesChamp(dictionary.getDataEntityFromEastPath("AFIN.BLOC_IDENTIFICATION.VERSION.VALEUR_VERSION"));
	    System.out.println("Description : " + IF.getDescriptionChampCourant());
	    System.out.println("Type  : " + IF.getTypeChampCourant());
	    System.out.println("Complement : " + IF.getComplementInfo());
		IF.initDescriptionChampCourant();
		IF.initTypeChampCourant();
		IF.setComplementInfo(m);
		IF.noterCaracteristiquesChamp(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_PDV.VALEUR_REF_PDV"));
	    System.out.println("Description : " + IF.getDescriptionChampCourant());
	    System.out.println("Type  : " + IF.getTypeChampCourant());
	    System.out.println("Complement : " + IF.getComplementInfo());
		IF.initDescriptionChampCourant();
		IF.initTypeChampCourant();
		IF.setComplementInfo(m);
		IF.noterCaracteristiquesChamp(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_ARC_FIN.CPTOB.VALEUR_CPTOB"));
	    System.out.println("Description : " + IF.getDescriptionChampCourant());
	    System.out.println("Type  : " + IF.getTypeChampCourant());
	    System.out.println("Complement : " + IF.getComplementInfo());
	    IF.initDescriptionChampCourant();
		IF.initTypeChampCourant();
		IF.setComplementInfo(m);
		IF.noterCaracteristiquesChamp(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_ARC_FIN.NB_CALCULS_ARC.VALEUR_NB_CALCULS_ARC"));
	    System.out.println("Description : " + IF.getDescriptionChampCourant());
	    System.out.println("Type  : " + IF.getTypeChampCourant());
	    System.out.println("Complement : " + IF.getComplementInfo());
	    */
		System.out.println("*******************************");
//		IF.setLesTypesConnus(liste);
//        Ligne ligne = new Ligne();
//		IF.noterCaracteristiquesChamp(dictionary.getDataEntityFromEastPath("AFIN.BLOC_IDENTIFICATION.VERSION.VALEUR_VERSION"),ligne);
//		IF.enregistrerUneLigne(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_PDV"));
//		IF.enregistrerUneLigne(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_ARC_FIN.CPTOB"));
//		IF.enregistrerUneLigne(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_ARC_FIN.NB_CALCULS_ARC"));

/*
        	System.out.println(ligne.motCle + new Integer(ligne.indice));
        	System.out.println(ligne.condition);
        	System.out.println(ligne.description);
        	System.out.println(ligne.type);
        	Map infos = ligne.complementInfo;
        	Set s = infos.entrySet();
        	Iterator i = s.iterator();
        	while (i.hasNext()) {
        		Map.Entry e = (Map.Entry)i.next();
        		String k = (String) e.getKey();
        		List values = (List)e.getValue();
        		
        	    System.out.println(k);
        	    System.out.println(values);
        	}
        		*/
		/*
		IF.setContexteDiscriminant("AFIN.BLOC_IDENTIFICATION.NOM_SATELLITE.VALEUR_SATELLITE = [HE2A]");
		int presence = IF.presenceEntite(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_SEQ_PDV"));
		System.out.println(presence);
		IF.setContexteDiscriminant("AFIN.BLOC_IDENTIFICATION.NOM_SATELLITE.VALEUR_SATELLITE = [HE1A]");
		presence = IF.presenceEntite(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_SEQ_PDV"));
		System.out.println(presence);
		IF.setContexteDiscriminant("");
		presence = IF.presenceEntite(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_SEQ_PDV"));
		System.out.println(presence);
		*/
		List lesSatellites = new ArrayList();
		lesSatellites.add("");
		Map lesDiscriminants = dictionary.getDiscriminantMap();
		Set s = lesDiscriminants.entrySet();
		Iterator i = s.iterator();
		while (i.hasNext()) {
			Map.Entry e = (Map.Entry)i.next();
			String disc = (String) e.getKey();
			if (disc.indexOf("SATELLITE") != -1) {
				// C'est le bon discriminant
				DEDDataEntity entity = dictionary.getDataEntityFromEastPath(disc);
				DEDDataEntity dataDef;
				if ( entity.getInheritsFrom() != null ) {
			          dataDef = entity.getInheritsFrom();
			   }
			   else {
			          dataDef = entity;
			   }
			   if (dataDef.isEnumerated()) {
			         DEDEnumeratedType enume = (DEDEnumeratedType)dataDef.getEntityType();
			         List al = enume.getEnumerations();
				     
				     Iterator it = al.iterator();
				     while (it.hasNext()) {
				     	DEDEnumeration valEnum = (DEDEnumeration) it.next();
				     	lesSatellites.add(valEnum.getValue());
				     }
			   }
			   break;
			}
		}
		System.out.println(lesSatellites);
		
		IF.setContexteDiscriminant("AFIN.BLOC_IDENTIFICATION.NOM_SATELLITE.VALEUR_SATELLITE = [SPOT4]");
		int presence = IF.presenceEntite(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_SEQ_PDV"));
		System.out.println(presence);
		IF.setContexteDiscriminant("AFIN.BLOC_IDENTIFICATION.NOM_SATELLITE.VALEUR_SATELLITE = [SPOT5]");
		presence = IF.presenceEntite(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_SEQ_PDV"));
		System.out.println(presence);
		IF.setContexteDiscriminant("");
		presence = IF.presenceEntite(dictionary.getDataEntityFromEastPath("AFIN.ENS_BLOCS_ARCS.TAB_ARCS.ARC.BLOC_DESC_ARCS.PDV.REF_SEQ_PDV"));
		System.out.println(presence);
		
	}
	
}
