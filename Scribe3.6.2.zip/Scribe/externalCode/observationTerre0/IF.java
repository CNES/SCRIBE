/*
 * Created on 14 oct. 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package observationTerre;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import scribe.ded.DEDComponent;
import scribe.ded.DEDCompositeType;
import scribe.ded.DEDDataEntity;
import scribe.ded.DEDEnumeratedType;
import scribe.ded.DEDEnumeration;
import scribe.ded.DEDIntegerType;
import scribe.ded.DEDRealType;
import scribe.ded.DEDTextType;

/**
 * @author LarzulB
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class IF {
	
	// Indique si un champ est pr�sent, absent ou conditionne 
	// dans le contexte courant (H1, H2).
	public static int PRESENT = 0;
	public static int ABSENT = 1;
	public static int CONDITIONNE = 2;
	
	private static String discr(String condition) {
		int ind = condition.indexOf("[");
		String d = condition.substring(0,ind);
		return d;
	}
	private static List valeurs(String condition) {
		if (condition.length() == 0) return new ArrayList();
		List lesValeurs = new ArrayList();
		int fin = 0;
		int ind = condition.indexOf("[");
		condition = condition.substring(ind+1,condition.length());
		while (((fin = condition.indexOf(",")) != -1) ||
		 ((fin = condition.lastIndexOf("..")) != -1)){
			if ((fin = condition.indexOf(",")) != -1) {
				lesValeurs.add(condition.substring(0,fin));
			    condition = condition.substring(fin+1,condition.length());
			}
			else if ((fin = condition.indexOf("..")) != -1) { 
				lesValeurs.add(condition.substring(0,fin));
			    condition = condition.substring(fin+2,condition.length());
			}
			
		}
		fin = condition.indexOf("]");
		lesValeurs.add(condition.substring(0,fin));
		return lesValeurs;
	}
	
	public static int presenceEntite(DEDDataEntity entity) {
		// Analyse les conditions de pr�sence de l'entit�
		// et les compare au contexteDiscriminant courant
		// A FAIRE
		String condition;
		condition = reportCondition(entity);
		if (condition.equals("")) {
			// pas de report
			if (entity.isConditioned()) {
				condition = (String) entity.getConditionsList().get(0);
			}
		}
		if (!condition.equals("")) {
			if (!contexteDiscriminant.equals("")) {
				if (discr(condition).equals(discr(contexteDiscriminant))) {
					// meme discriminant
					
//					 Pour test : 1 seule valeur
					String val = (String) valeurs(contexteDiscriminant).get(0);
					if (valeurs(condition).contains(val)) {
						return PRESENT;
					}
					else return ABSENT;
				}
				else {
					// pas le meme discriminant
					return CONDITIONNE;
				}
			}
			else return CONDITIONNE;
		}
		return PRESENT;
	}

	private static String reportCondition(DEDDataEntity entity) {
        // Un champ est dit conditionn� dans le contexte H�lios si
		// 1. Il est lui m�me conditionn�
		// 2. Un champ parent est conditionn�
		// 3. Tous ces champs fils sont conditionn�s par la m�me condition
		// Cas 3 traite ici.
		String condCommune = "";
		List lesFils = entity.getChildrenList();
		if (lesFils != null) {
			Iterator it = lesFils.iterator();
			while (it.hasNext()) {
				DEDDataEntity fils = (DEDDataEntity) it.next();
				String condCourante = fils.getExistsIf();
				if (condCourante == null) return "";
				if (condCommune.equals("")) condCommune = condCourante;
				else if (!condCommune.equals(condCourante)) return "";
			}
			return condCommune;
		}
		else return "";
	}
	
	private static String nomCourt(String nomLong) {
		int index = nomLong.lastIndexOf(".");
		return nomLong.substring(index+1);
	}

	public static String ordonnancementDesBlocs(List l) {
		if (l == null) return "";
		String ordre = "";
		Iterator it = l.iterator();
		while (it.hasNext()) {
			DEDDataEntity entity = (DEDDataEntity) it.next();
			String name = entity.getName();
			if (name.startsWith("BLOC_")) {
				// On a un bloc
				int p = presenceEntite(entity);
				if (p != ABSENT) {
				   if (ordre.length() > 0) ordre += " + ";
				   //if (!reportCondition(entity).equals("") || entity.isConditioned()) 
				   if (p == CONDITIONNE) ordre += "?";

                           // Est-ce que le BLOC contient des TAB ?
                           List sousListe = entity.getChildrenList();
                           if (sousListe.size() == 1) {
                              DEDDataEntity fils = (DEDDataEntity) sousListe.get(0);
                              if (fils.getName().startsWith("TAB_")) {
                                 DEDDataEntity dataDef;
				         if (fils.getInheritsFrom() != null) {
					      dataDef = fils.getInheritsFrom();
				         } else {
				            dataDef = fils;
				         }
				         DEDCompositeType composite = (DEDCompositeType) dataDef
						.getEntityType();
				         DEDComponent component = (DEDComponent) composite
						.getComponents().get(0);
				         String nb = component.getMaxValue();
				
				         ordre += nomCourt(nb) + " * " + name.substring(5);
                              }
                           }
                              
                           else {
				      ordre += name.substring(5);
                           }
				}
			}
			if (name.startsWith("TAB_")) {
				DEDDataEntity dataDef;
				if (entity.getInheritsFrom() != null) {
					dataDef = entity.getInheritsFrom();
				} else {
					dataDef = entity;
				}
				DEDCompositeType composite = (DEDCompositeType) dataDef
						.getEntityType();
				DEDComponent component = (DEDComponent) composite
						.getComponents().get(0);
				String nb = component.getMaxValue();
				String sousOrdre = ordonnancementDesBlocs(entity.getChildrenList());
				if (!sousOrdre.equals("")) {
				   ordre +=  " + " + nomCourt(nb) + " * (";
				   ordre += sousOrdre;
				   ordre += ")";
				}
			} else {
				// Structure qui contient des blocs ou un tableau de blocs
				ordre += ordonnancementDesBlocs(entity.getChildrenList());

			}
		}
		return ordre;
	}
	
	public static String listeDesBlocs(List l) {
		
		if (l == null) return "";
		String resultat = "";
		Iterator it = l.iterator();
		while (it.hasNext()) {
		   DEDDataEntity entity = (DEDDataEntity) it.next();
		   String name = entity.getName();
		   if (name.startsWith("BLOC_")) {
		      
		      if (presenceEntite(entity) != ABSENT) {
		      	if (!resultat.equals("")) {
			      	resultat += "<br>";
			    }
		        resultat += name.substring(5);
		      }
		   }
		   else  {
			  // Structure qui contient des blocs ou un tableau de blocs
			  String r = listeDesBlocs(entity.getChildrenList());
			  if (!resultat.equals("")) {
			  	if (!r.equals("")) {
			  		resultat += "<br>";
			  	}
		      }
		      resultat += r;
		   }
		}


		return resultat;
	}
	public static String occurrenceEntite(DEDDataEntity entity) {
		String occurrence = "";
		// Est-ce qu'un des parents est un tableau ?
		
		// Note : il ne faut pas remonter au del� du bloc
		// i.e. ne pas mentionner l'occurrence du bloc
		
		DEDDataEntity data;
		DEDDataEntity child;
		DEDDataEntity dataDef;
		data = entity.getParent();
		child = entity;
		while ((data != null) && (data != leBlocCourant)){
		   if ( data.getInheritsFrom() != null ) {
				   dataDef = data.getInheritsFrom();
				}
				else {
				   dataDef = entity;
				}
		   if (dataDef.isComposite()) {
		        Object obj = dataDef.getEntityType();
		        DEDCompositeType composite = (DEDCompositeType)obj;
		        ArrayList al = composite.getComponents();
		        DEDComponent component;
		        int size = al.size();

		        for (int i = 0; i < size; i++) {
		        component = (DEDComponent)al.get(i);
		        if (component.getName().equals(child.getName())) {
		        	if (!component.getMaxValue().equals("")) {
		                
		                 // on a trouve un tableau

		        		 occurrence = component.getMaxValue();
		                 return occurrence;
		        	}
		        }
		        }
		   }
		   child = data;
		   data = data.getParent();
		}
		return occurrence;
	}
	public static String conditionsEntite(DEDDataEntity entity) {
		String condition = "";
		String cond = reportCondition(entity);
		if (!cond.equals("") || entity.isConditioned()) {
			condition += cond;
			List lesAutresConditions = entity.getConditionsList();
			Iterator i = lesAutresConditions.iterator();
			while (i.hasNext()) {
				condition += (String)i.next();
			}
		}
		return condition;
	}
	public static String conditionsDesBlocs(List l) {
		if (l == null) return "";
		String condition = "";
		Iterator it = l.iterator();
		while (it.hasNext()) {
			DEDDataEntity entity = (DEDDataEntity) it.next();
			String name = entity.getName();
			if (name.startsWith("BLOC_")) {
				// On a un bloc
				if (presenceEntite(entity) == CONDITIONNE) {
				    String cond = conditionsEntite(entity);
					if (condition.length() > 0) condition += "<br>";
					condition += "Condition d'existence du bloc ";
					condition += name.substring(5);
					condition += " : ";
					condition += cond;
				}
			}
			else {
				// Structure qui contient des blocs ou un tableau de blocs
				condition += conditionsDesBlocs(entity.getChildrenList());

			}
		}
		return condition;
	}
	private static List lesTypesConnus;
	private static DEDDataEntity leBlocCourant;
	private static Map correspondanceCaracteres = new HashMap();
	private static String contexteDiscriminant = "";
		
	
	public static void setContexteDiscriminant(String contexte) {
		contexteDiscriminant = contexte.replaceAll(" = ","");

	}
	public static void initCorrespondanceCaracteres() {
		correspondanceCaracteres.clear();
		correspondanceCaracteres.put("ASCII.LF","Cr");
		correspondanceCaracteres.put("' '","SPC");
	}
    public static void setLeBlocCourant(DEDDataEntity leBloc) {
		leBlocCourant = leBloc;
	}
    
	public static DEDDataEntity getLeBlocCourant() {
		return leBlocCourant;
	}
	public static void setLesTypesConnus(List l) {
		lesTypesConnus = l;
	}

	public static String contenuDeLaLigne(DEDDataEntity dataField) {
        //	S'applique � une ligne SR-6-10
		String laLigne = "";



		List l = dataField.getChildrenList();

		Iterator it = l.iterator();
		while (it.hasNext()) {
		   DEDDataEntity entity = (DEDDataEntity) it.next();
		   if (presenceEntite(entity) != ABSENT) {
		   String name = entity.getName();

		   // On regarde le type
		   DEDDataEntity dataDef = null;
		   String typeName = null;
		   if ( entity.getInheritsFrom() != null ) {
		          dataDef = entity.getInheritsFrom();
		          typeName = dataDef.getName();
		   }
		   else {
		          dataDef = entity;
			  typeName = "";
		   }
		   // Si c'est un Enumerated a 1 valeur on donne la valeur
		   // Si c'est un caract�re, on le met entre []
		   // Si c'est un Enumerated a n valeurs on donne le nom du champ
		   // Si c'est une structure, on donne les champs de la structure
		   // etc...
		   if (dataDef.isEnumerated()) {
		         DEDEnumeratedType e = (DEDEnumeratedType)dataDef.getEntityType();
		         List al = e.getEnumerations();
			 DEDEnumeration valEnum;
			 int size = al.size();
		         if (size > 1) laLigne+=name;
			 else {
		            valEnum = (DEDEnumeration)al.get(0);
		            laLigne += "<b>"  + valEnum.getConvention() + "</b>";
		   	 }
		   }
		   else if (dataDef.isText()) {
		      DEDTextType t = (DEDTextType)dataDef.getEntityType();
		      if (t.getMinSize().equals("1") && (t.getMaxSize().equals("1")) ) {
		         // Character
		         String r = dataDef.getAttributeByName("CHARACTER_RANGE");
		         int i = r.indexOf("..");
			     String min = r.substring(0,i);
		         String max = r.substring(i+2,r.length());
		         if (min.equals(max)) {

		            String val = (String)correspondanceCaracteres.get(min);
		            if (val != null) {
		                // il y a une correspondance pour ce caractere
		                min = val;
		            }
		            else min = min.replaceAll("'","");
		            if (min.equals("<") || min.equals(">")) {
				        //traitement particulier
		                laLigne += "<b>"+min+"</b>";
			        }
		            else laLigne += "["+min+"]";

		         }
		         else laLigne += name;
		      }
		      else laLigne += name;
		   }
		   else if (dataDef.isComposite()) {
		   	  laLigne += contenuDeLaLigne(entity);
		   }
		   else laLigne += name;

		   }
		}
		return laLigne;
	}
	public static void noterCaracteristiquesChamp(DEDDataEntity entity, Ligne ligne) {


			String nbElements = "";
			// On regarde le type du champ
			DEDDataEntity dataDef = null;
			String typeName = "";
			if ( entity.getInheritsFrom() != null ) {
			      dataDef = entity.getInheritsFrom();
			      typeName = dataDef.getName();
			}
			else {
			      dataDef = entity;
			}
			   
			// Est-ce un tableau ?
			String nature = dataDef.getAttributeByName("NATURE");
			if (nature.equals("ARRAY")) {
			   DEDCompositeType composite = (DEDCompositeType)dataDef.getEntityType();
			   DEDComponent component = (DEDComponent)composite.getComponents().get(0);
			  nbElements = " * " + nomCourt(component.getMaxValue());
			}
			if (dataDef.isEnumerated()) {
			     DEDEnumeratedType e = (DEDEnumeratedType)dataDef.getEntityType();
			     List al = e.getEnumerations();
			     DEDEnumeration valEnum;
			     int size = al.size();
			     if (size > 1) {
			     	ligne.description += "[";

			        for (int i=0; i < size; i++) {
			           valEnum = (DEDEnumeration)al.get(i);
			           ligne.description += " \""  + valEnum.getConvention() + "\" ";
			        }

			        ligne.description += "]";
			        ligne.type += "ENUMERATED";
			     }
			     else {
			     	valEnum = (DEDEnumeration)al.get(0);
			     	ligne.type += "[\""  + valEnum.getConvention() + "\"]";
			     }
			  }
			  if (dataDef.isInteger()) {
			  	 DEDIntegerType i = (DEDIntegerType)dataDef.getEntityType();
			  	 ligne.type += "INTEGER["+i.getMinValue()+" .. "+i.getMaxValue()+"]";
			  }
			  if (dataDef.isReal()) {
			  	 DEDRealType r = (DEDRealType)dataDef.getEntityType();
			     String min = r.getMinValue();
			     String max = r.getMaxValue();
			     if ((!min.equals("")) && (!max.equals(""))) {
			        ligne.type += "REAL["+min+" .. "+max+"]";
			     } else ligne.type += "REAL";
			  }
                    if (dataDef.isText()) {
                       DEDTextType t = (DEDTextType)dataDef.getEntityType();
			     String max = t.getMaxSize();
                       if (max.equals("1") || max.equals("")) {
				  ligne.type += "CHARACTER";
                       }
                       else ligne.type += max + " CHARACTERS";
                    }

			  if (dataDef.isComposite()) {
			 // on affiche ses champs composites
			 // sauf si le champ a un nom de type "connu"
			     if (!lesTypesConnus.contains(typeName)) {
			        List lesFils = entity.getChildrenList();
			        Iterator itFils = lesFils.iterator();
			        ligne.description += "( ";
			        while (itFils.hasNext()) {
			            DEDDataEntity fils = (DEDDataEntity) itFils.next();
			            noterCaracteristiquesChampComposite(fils, nbElements, ligne);
			        }
			        ligne.description += " )";
			     }
			     else {
			     	ligne.type += typeName;
			     }
			  }
			  


		}
      private static boolean aUneSeuleValeur(String range) {

         if (range == null) return false;
         if (range.equals("")) return false;
         int index = range.indexOf("..");
         String min = range.substring(0,index);
         String max = range.substring(index + 2, range.length());
         if (min.equals(max)) return true;
         else return false;

      }

	private static void noterCaracteristiquesChampComposite(DEDDataEntity entity, String nbElements, Ligne ligne) {
		String nbElementsSuite = "";
		if (presenceEntite(entity) == ABSENT) return;
		String entityName = entity.getName() + nbElements;
        // On regarde le type du champ
	    DEDDataEntity dataDef = null;
	    String typeName = "";
	    if ( entity.getInheritsFrom() != null ) {
	          dataDef = entity.getInheritsFrom();
	          typeName = dataDef.getName();
	    }
	    else {
	          dataDef = entity;
	    }
	    // Est-ce qu'il est conditionn� par un discriminant ?
	    // Alors que la ligne ne l'est pas ?
	    //if (entity.isConditioned()) {
	    if (presenceEntite(entity) == CONDITIONNE) {
	    	entityName = "?"+entityName;
	    	String condition = (String) entity.getConditionsList().get(0);
	    	String conditionCourante = ligne.condition;
	    	if (!condition.equals(conditionCourante)) {
	    	String key = entity.getName();
	    	List value;
	    	if (ligne.complementInfo.containsKey(key)) {
	    		value = (List) ligne.complementInfo.get(key);
	    	}
	    	else value = new ArrayList();
	    	value.add("Condition d'existence : " + condition + "<br>");
	    	ligne.complementInfo.put(key,value);
	    	}
	    }
        // Est-ce un tableau ?
	    String nature = dataDef.getAttributeByName("NATURE");
	    if (nature.equals("ARRAY")) {
	       DEDCompositeType composite = (DEDCompositeType)dataDef.getEntityType();
	 	   DEDComponent component = (DEDComponent)composite.getComponents().get(0);
	 	  nbElementsSuite = " * " + nomCourt(component.getMaxValue());
	    }
	    // Est-ce qu'il y a une description associ�e au champ ?
        // On regarde le MEANING
	    String desc = entity.getAttributeByName( "MEANING" );
	    if (desc != null) {
	    	String key = entity.getName();
	    	List value;
	    	if (ligne.complementInfo.containsKey(key)) {
	    		value = (List) ligne.complementInfo.get(key);
	    	}
	    	else value = new ArrayList();
	    	value.add("Definition : " + desc + "<br>");
	    	ligne.complementInfo.put(key,value);
	    }
	    
	    if (dataDef.isEnumerated()) {
	    	 ligne.description += "[" + entityName + "]";
	         DEDEnumeratedType e = (DEDEnumeratedType)dataDef.getEntityType();
	         List al = e.getEnumerations();
		     DEDEnumeration valEnum;
		     int size = al.size();
	         if (size > 1) {
	         	List value;
	         	String key = entity.getName();
	         	if (ligne.complementInfo.containsKey(key)) {
		    		value = (List) ligne.complementInfo.get(key);
		    	}
		    	else value = new ArrayList();
		    	String t = "ENUMERATED in [";

	            for (int i=0; i < size; i++) {
	               valEnum = (DEDEnumeration)al.get(i);
	               t += " \""  + valEnum.getConvention() + "\" ";
	            }

	            t += "]";
	            value.add("Type : " + t + "<br>");
	            ligne.complementInfo.put(key,value);
		    	
	            ligne.type += "ENUMERATED <br>";
	   	     }
	         else {
	         	valEnum = (DEDEnumeration)al.get(0);
	         	ligne.type += "[\""  + valEnum.getConvention() + "\"] <br>" ;
	         }
	      }
	      if (dataDef.isInteger()) {
	      	 ligne.description += "[" + entityName + "]";
	      	 DEDIntegerType i = (DEDIntegerType)dataDef.getEntityType();
	      	ligne.type += "INTEGER["+i.getMinValue()+" .. "+i.getMaxValue()+"] <br>";
	      }
	      if (dataDef.isReal()) {
	      	 ligne.description += "[" + entityName + "]";
	      	 DEDRealType r = (DEDRealType)dataDef.getEntityType();
	   	     String min = r.getMinValue();
	         String max = r.getMaxValue();
	   	     if ((!min.equals("")) && (!max.equals(""))) {
	   	        ligne.type += "REAL["+min+" .. "+max+"] <br>";
	         } else ligne.type += "REAL <br>";
	      }

	      if (dataDef.isComposite()) {
		 // on affiche ses champs composites
	         //if (!lesTypesConnus.contains(typeName)) {
	            List lesFils = entity.getChildrenList();
		        Iterator itFils = lesFils.iterator();
		        ligne.description += " ( ";
	            while (itFils.hasNext()) {
	                DEDDataEntity fils = (DEDDataEntity) itFils.next();
	                noterCaracteristiquesChampComposite(fils, nbElementsSuite,ligne);
	            }
	            ligne.description += " ) " + nbElements;
	         //}
	         //else {
	         //	typeChampCourant += typeName +" <br>";
	         //}
	      }
          // On ignore les caract�res (Text) de s�paration

            if (dataDef.isText()) {
               String range = dataDef.getAttributeByName("CHARACTER_RANGE");
		   
	         if (!aUneSeuleValeur(range)) {
                  ligne.description += "[" + entityName + "]";
                  DEDTextType t = (DEDTextType)dataDef.getEntityType();
		      String max = t.getMaxSize();
                  if (max.equals("1") || max.equals("")) {
				  ligne.type += "CHARACTER <br>";
                  }
                  else ligne.type += max + " CHARACTERS <br>";
               }
		   
            }
// Pour debug
//catch (Exception e) {
//JOptionPane.showMessageDialog(
//null,
//e.toString(),
//"exception",
//JOptionPane.WARNING_MESSAGE);
//}

	   } 
	
}