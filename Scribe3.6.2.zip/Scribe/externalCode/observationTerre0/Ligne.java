/*
 * Created on 18 oct. 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package observationTerre;

import java.util.HashMap;
import java.util.Map;

/**
 * @author LarzulB
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Ligne {
	
	public String motCle = "";
	public int indice = 1;
	public String condition = "";
	public String occurrence = "";
	public String description = "";
	public String type = "";
	public Map complementInfo = new HashMap();


}
