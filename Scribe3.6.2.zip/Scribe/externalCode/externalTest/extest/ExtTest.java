/*
 * Created on 23 sept. 2004
 *
 */
package externalTest.extest;
import java.util.*;
import scribe.ded.DEDDictionary;

/**
 * @author JML
 *
 */
public class ExtTest {
	private static DEDDictionary dictionary;
	//private static Map TableauPharao = new HashMap();

   public ExtTest() {}

   public String sayHello() {
   	   //dictionary = dico;
	   return "Hello from outside enfin !";
   }

   public String sayHelloDED(DEDDictionary dico) {
   	   dictionary = dico;
	   return "DED Hello from outside more !";
   }

   public static String sayStaticHello() {
   	   //dictionary = dico;
	   return "Static Hello from outside again !";
   }

}
